import java.util.Scanner;

public class caixa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite o valor inicial na conta: $");
        double saldoInicial = scanner.nextDouble();

        Conta conta = new Conta(nome, saldoInicial);

        exibirMenu(conta, scanner);
    }

    public static void exibirMenu(Conta conta, Scanner scanner) {
        int opcao;
        do {
            System.out.println("\n=== Caixa Eletrônico ===");
            System.out.println("1. Extrato");
            System.out.println("2. Sacar");
            System.out.println("3. Depositar");
            System.out.println("4. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    exibirExtrato(conta);
                    break;
                case 2:
                    System.out.print("Digite o valor a ser sacado: $");
                    double valorSaque = scanner.nextDouble();
                    conta.sacar(valorSaque);
                    break;
                case 3:
                    System.out.print("Digite o valor a ser depositado: $");
                    double valorDeposito = scanner.nextDouble();
                    conta.depositar(valorDeposito);
                    break;
                case 4:
                    System.out.println("Saindo do Caixa Eletrônico. Obrigado!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 4);
    }

    public static void exibirExtrato(Conta conta) {
        System.out.println("\n=== Extrato ===");
        System.out.println("Nome: " + conta.getNome());
        System.out.println("Número da Conta: " + conta.getNumeroConta());
        System.out.println("Saldo: $" + conta.getSaldo());
        System.out.println("Saques Realizados hoje: " + conta.getSaquesRealizados());
    }
}




