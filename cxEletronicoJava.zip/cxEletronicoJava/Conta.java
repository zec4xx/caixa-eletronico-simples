public class Conta {
    private String nome;
    private int numeroConta;
    private double saldo;
    private int saquesRealizados;

    public Conta(String nome, double saldo) {
        this.nome = nome;
        this.saldo = saldo;
        this.numeroConta = gerarNumeroConta();
        this.saquesRealizados = 0;
    }

    public String getNome() {
        return nome;
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public int getSaquesRealizados() {
        return saquesRealizados;
    }

    public void sacar(double valor) {
        if (valor <= saldo && saquesRealizados < 5) {
            saldo -= valor;
            saquesRealizados++;
            System.out.println("Saque de $" + valor + " realizado com sucesso. Novo saldo: $" + saldo);
        } else {
            System.out.println("Não é possível sacar o valor solicitado ou excedeu o limite de saques diários.");
        }
    }

    public void depositar(double valor) {
        saldo += valor;
        System.out.println("Depósito de $" + valor + " realizado com sucesso. Novo saldo: $" + saldo);
    }

    private int gerarNumeroConta() {
        
        return (int) (Math.random() * 9000) + 1000;
    }
}
